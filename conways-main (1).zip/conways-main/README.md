# conways



print
